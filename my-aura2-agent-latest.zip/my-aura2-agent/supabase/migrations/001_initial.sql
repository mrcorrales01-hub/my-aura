-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Table: profiles
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users (id) ON DELETE CASCADE,
  display_name TEXT,
  locale TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: mood_entries
CREATE TABLE IF NOT EXISTS mood_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users (id) ON DELETE CASCADE,
  date DATE NOT NULL,
  score INT NOT NULL CHECK (score >= 1 AND score <= 5),
  note TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: chat_sessions
CREATE TABLE IF NOT EXISTS chat_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users (id) ON DELETE CASCADE,
  started_at TIMESTAMPTZ DEFAULT NOW(),
  ended_at TIMESTAMPTZ
);

-- Table: messages
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES chat_sessions (id) ON DELETE CASCADE,
  role TEXT CHECK (role IN ('user','assistant')),
  content TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: exercise_videos
CREATE TABLE IF NOT EXISTS exercise_videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  url TEXT NOT NULL,
  duration_sec INT NOT NULL,
  tags TEXT[],
  is_premium BOOL DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: favorite_videos
CREATE TABLE IF NOT EXISTS favorite_videos (
  user_id UUID REFERENCES auth.users (id) ON DELETE CASCADE,
  video_id UUID REFERENCES exercise_videos (id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (user_id, video_id)
);

-- Table: video_progress
CREATE TABLE IF NOT EXISTS video_progress (
  user_id UUID REFERENCES auth.users (id) ON DELETE CASCADE,
  video_id UUID REFERENCES exercise_videos (id) ON DELETE CASCADE,
  position_sec INT DEFAULT 0,
  completed BOOL DEFAULT FALSE,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (user_id, video_id)
);

-- Table: subscriptions
CREATE TABLE IF NOT EXISTS subscriptions (
  user_id UUID PRIMARY KEY REFERENCES auth.users (id) ON DELETE CASCADE,
  status TEXT,
  tier TEXT,
  current_period_end TIMESTAMPTZ
);

-- Table: care_plans
CREATE TABLE IF NOT EXISTS care_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users (id) ON DELETE CASCADE,
  status TEXT CHECK (status IN ('active','paused','archived')) DEFAULT 'active',
  started_at TIMESTAMPTZ DEFAULT NOW(),
  review_cadence TEXT DEFAULT 'weekly'
);

-- Table: goals
CREATE TABLE IF NOT EXISTS goals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id UUID REFERENCES care_plans (id) ON DELETE CASCADE,
  type TEXT CHECK (type IN ('short','long')),
  title TEXT NOT NULL,
  description TEXT,
  smart JSONB,
  target_date DATE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  archived BOOL DEFAULT FALSE
);

-- Table: plan_tasks
CREATE TABLE IF NOT EXISTS plan_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  goal_id UUID REFERENCES goals (id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  due_date DATE NOT NULL,
  done BOOL DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: plan_reviews
CREATE TABLE IF NOT EXISTS plan_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id UUID REFERENCES care_plans (id) ON DELETE CASCADE,
  review_date DATE NOT NULL,
  adherence INT CHECK (adherence >= 0 AND adherence <= 100),
  notes TEXT,
  next_focus TEXT
);

-- Table: quests
CREATE TABLE IF NOT EXISTS quests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE,
  title TEXT,
  description TEXT,
  tags TEXT[],
  lang TEXT DEFAULT 'en',
  active BOOL DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: user_quests
CREATE TABLE IF NOT EXISTS user_quests (
  user_id UUID REFERENCES auth.users (id) ON DELETE CASCADE,
  quest_id UUID REFERENCES quests (id) ON DELETE CASCADE,
  date DATE DEFAULT CURRENT_DATE,
  status TEXT CHECK (status IN ('todo','done','skipped')) DEFAULT 'todo',
  PRIMARY KEY (user_id, quest_id, date)
);

-- Enable Row Level Security (RLS)
ALTER TABLE mood_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE favorite_videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE care_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE plan_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE plan_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_quests ENABLE ROW LEVEL SECURITY;

-- Policies for user-specific tables
CREATE POLICY "profiles_read" ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "profiles_update" ON profiles FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "mood_entries_crud" ON mood_entries
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "chat_sessions_crud" ON chat_sessions
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "messages_crud" ON messages
  FOR ALL USING (
    auth.uid() = (
      SELECT user_id FROM chat_sessions WHERE chat_sessions.id = messages.session_id
    )
  );

CREATE POLICY "favorite_videos_crud" ON favorite_videos
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "video_progress_crud" ON video_progress
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "subscriptions_crud" ON subscriptions
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "care_plans_crud" ON care_plans
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "goals_crud" ON goals
  FOR ALL USING (
    auth.uid() = (
      SELECT user_id FROM care_plans WHERE care_plans.id = goals.plan_id
    )
  );

CREATE POLICY "plan_tasks_crud" ON plan_tasks
  FOR ALL USING (
    auth.uid() = (
      SELECT user_id FROM care_plans
      JOIN goals ON goals.plan_id = care_plans.id
      WHERE goals.id = plan_tasks.goal_id
    )
  );

CREATE POLICY "plan_reviews_crud" ON plan_reviews
  FOR ALL USING (
    auth.uid() = (
      SELECT user_id FROM care_plans WHERE care_plans.id = plan_reviews.plan_id
    )
  );

CREATE POLICY "user_quests_crud" ON user_quests
  FOR ALL USING (auth.uid() = user_id);

-- Public select on exercise_videos
ALTER TABLE exercise_videos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "exercise_videos_read" ON exercise_videos FOR SELECT USING (true);