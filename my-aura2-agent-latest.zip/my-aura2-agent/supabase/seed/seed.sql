-- Seed sample exercise videos
INSERT INTO exercise_videos (id, title, url, duration_sec, tags, is_premium)
VALUES
  (gen_random_uuid(), 'Guided Breathing', 'https://samplelib.com/lib/preview/mp4/sample-5s.mp4', 300, ARRAY['andning','lugn'], FALSE),
  (gen_random_uuid(), 'Mindful Focus', 'https://samplelib.com/lib/preview/mp4/sample-5s.mp4', 420, ARRAY['fokus','stress'], TRUE),
  (gen_random_uuid(), 'Energising Stretch', 'https://samplelib.com/lib/preview/mp4/sample-5s.mp4', 360, ARRAY['energi','motivation'], FALSE);

-- Seed quests mapped to focus areas
INSERT INTO quests (id, key, title, description, tags, lang, active)
VALUES
  (gen_random_uuid(), 'q_breath_1', 'Take 3 deep breaths', 'Stand up and take three deep breaths, focusing on your lungs.', ARRAY['andning'], 'en', TRUE),
  (gen_random_uuid(), 'q_walk_1', 'Short walk', 'Walk for 5 minutes, paying attention to your surroundings.', ARRAY['stress'], 'en', TRUE),
  (gen_random_uuid(), 'q_meditate_1', '1-minute meditation', 'Sit quietly and count your breaths for one minute.', ARRAY['fokus'], 'en', TRUE),
  (gen_random_uuid(), 'q_sleep_hygiene', 'Sleep hygiene', 'Avoid screens 30 minutes before bed.', ARRAY['sömn','anxiety'], 'en', TRUE);