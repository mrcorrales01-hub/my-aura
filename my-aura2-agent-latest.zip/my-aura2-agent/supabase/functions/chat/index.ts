// deno-lint-ignore-file no-explicit-any
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';

// In a real implementation this function would call an LLM endpoint such
// as OpenAI or Anthropic with appropriate safety prompts. For this skeleton
// we simply echo back a canned response in a server-sent events stream.

serve(async (req: Request) => {
  if (req.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }
  const { message, lang } = (await req.json()) as { message: string; lang: string };
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    start(controller) {
      // Simulate a streaming response by sending a greeting and echoing the input
      const responses = [
        `data: Auri (${lang}): Hej!\n\n`,
        `data: Du sa: ${message}\n\n`,
        `data: Tack för att du pratar med mig!\n\n`,
      ];
      for (const chunk of responses) {
        controller.enqueue(encoder.encode(chunk));
      }
      controller.close();
    },
  });
  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Connection': 'keep-alive',
      'Cache-Control': 'no-cache',
    },
  });
});