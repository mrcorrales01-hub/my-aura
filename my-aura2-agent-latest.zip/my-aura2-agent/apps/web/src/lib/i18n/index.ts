import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import en from './locales/en.json';
import sv from './locales/sv.json';
import es from './locales/es.json';
import da from './locales/da.json';
import no from './locales/no.json';
import fi from './locales/fi.json';

// Supported languages and their resources
const resources = {
  en: { translation: en },
  sv: { translation: sv },
  es: { translation: es },
  da: { translation: da },
  no: { translation: no },
  fi: { translation: fi },
};

/**
 * Detects the default language for the user based on a combination of
 * saved preferences, browser language, and timezone. Falls back to
 * English if no appropriate match is found.
 */
function detectDefault(): string {
  // If a language is stored in localStorage, use it
  const stored = localStorage.getItem('lang');
  if (stored && resources[stored as keyof typeof resources]) {
    return stored;
  }
  // Browser language detection
  const navLang = navigator.language?.toLowerCase();
  if (navLang) {
    if (navLang.startsWith('sv')) return 'sv';
    if (navLang.startsWith('es')) return 'es';
    if (navLang.startsWith('da')) return 'da';
    if (navLang.startsWith('no')) return 'no';
    if (navLang.startsWith('fi')) return 'fi';
  }
  // Timezone detection for Sweden
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (tz === 'Europe/Stockholm') return 'sv';
  } catch {}
  // Default fallback
  return 'en';
}

const initialLng = detectDefault();

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: initialLng,
    fallbackLng: 'en',
    interpolation: { escapeValue: false },
    // React settings
    react: { useSuspense: false },
  });

/**
 * Change language at runtime. Updates both i18next and HTML attributes,
 * and persists the choice in localStorage.
 */
export async function loadLocale(lang: string) {
  const supported = Object.keys(resources);
  if (!supported.includes(lang)) return;
  await i18n.changeLanguage(lang);
  localStorage.setItem('lang', lang);
  // Update document language attribute
  document.documentElement.lang = lang;
  document.documentElement.dir = 'ltr';
}

export default i18n;