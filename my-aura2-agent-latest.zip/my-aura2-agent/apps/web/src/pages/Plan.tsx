import React from 'react';

/**
 * Plan page. Displays the user's care plan and allows creation.
 * The full wizard and review flows are outside the scope of this skeleton.
 */
const PlanPage: React.FC = () => {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Care Plan</h2>
      <p>Here you will be able to manage your personal care plan, set goals and review your progress.</p>
      <p>Plan creation functionality is under development.</p>
    </div>
  );
};

export default PlanPage;