import React from 'react';
import LanguageSwitcher from '@/features/settings/LanguageSwitcher';

/**
 * Settings page. Provides options to change language and other preferences.
 */
const SettingsPage: React.FC = () => {
  return (
    <div className="space-y-4 max-w-md mx-auto">
      <h2 className="text-2xl font-bold">Settings</h2>
      <div>
        <label className="block mb-2 font-medium">Language</label>
        <LanguageSwitcher />
      </div>
      {/* Placeholder for additional settings (e.g. theme, notifications) */}
    </div>
  );
};

export default SettingsPage;