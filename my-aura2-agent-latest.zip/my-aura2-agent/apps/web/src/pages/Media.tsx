import React from 'react';
import VideoList from '@/features/media/VideoList';

/**
 * Media page. Shows exercise videos with favourites and recommendations.
 */
const MediaPage: React.FC = () => {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Video Exercises</h2>
      <VideoList />
    </div>
  );
};

export default MediaPage;