import React from 'react';
import ChatBox from '@/features/chat/ChatBox';

/**
 * Chat page. Displays the ChatBox for conversation with Auri.
 */
const ChatPage: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto mt-4">
      <ChatBox />
    </div>
  );
};

export default ChatPage;