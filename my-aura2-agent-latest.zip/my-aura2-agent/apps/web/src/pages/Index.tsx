import React from 'react';
import Hero from '@/components/Hero';

/**
 * Landing page. Contains a hero section and a summary of key features.
 */
const Index: React.FC = () => {
  return (
    <div className="space-y-12">
      <Hero />
      <section id="features" className="space-y-8">
        <h2 className="text-3xl font-bold text-center">Features</h2>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          <FeatureCard
            title="AI Coach"
            description="Chat with Auri for personalised, compassionate support in your own language."
          />
          <FeatureCard
            title="Mood Tracking"
            description="Log your mood daily and visualise trends to understand your wellbeing."
          />
          <FeatureCard
            title="Video Exercises"
            description="Follow guided breathing and meditation videos to relax, focus and energise."
          />
        </div>
      </section>
    </div>
  );
};

interface FeatureCardProps {
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ title, description }) => (
  <div className="border rounded-2xl p-6 shadow hover:shadow-lg transition">
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-sm text-gray-700">{description}</p>
  </div>
);

export default Index;