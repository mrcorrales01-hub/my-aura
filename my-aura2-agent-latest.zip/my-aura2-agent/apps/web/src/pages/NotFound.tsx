import React from 'react';
import { Link } from 'react-router-dom';

/**
 * 404 page. Informs the user that the requested page was not found.
 */
const NotFoundPage: React.FC = () => {
  return (
    <div className="text-center space-y-4 py-20">
      <h1 className="text-4xl font-bold">404</h1>
      <p>The page you are looking for does not exist.</p>
      <Link to="/" className="text-aura-primary hover:underline">
        Back to Home
      </Link>
    </div>
  );
};

export default NotFoundPage;