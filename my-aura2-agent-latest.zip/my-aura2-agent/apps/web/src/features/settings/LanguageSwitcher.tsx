import React from 'react';
import { useTranslation } from 'react-i18next';

/**
 * LanguageSwitcher allows the user to change the current language. It
 * persists the choice in localStorage or in the user profile (future).
 */
const LanguageSwitcher: React.FC = () => {
  const { i18n } = useTranslation();
  const supported = ['sv', 'en', 'es', 'da', 'no', 'fi'];
  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const lang = e.target.value;
    i18n.changeLanguage(lang);
    localStorage.setItem('lang', lang);
  };
  return (
    <select
      value={i18n.language}
      onChange={handleChange}
      className="bg-white text-gray-900 border border-gray-300 rounded p-1"
    >
      {supported.map((lang) => (
        <option key={lang} value={lang}>
          {lang.toUpperCase()}
        </option>
      ))}
    </select>
  );
};

export default LanguageSwitcher;