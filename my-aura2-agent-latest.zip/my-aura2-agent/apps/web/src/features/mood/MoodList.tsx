import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import MoodChart from '@/components/MoodChart';

interface MoodEntry {
  id: string;
  date: string;
  score: number;
  note: string | null;
}

/**
 * Fetches mood entries from Supabase and displays them along with a chart.
 */
const MoodList: React.FC = () => {
  const { data, error, isLoading } = useQuery(['mood_entries'], async () => {
    const { data, error } = await supabase
      .from<MoodEntry>('mood_entries')
      .select('*')
      .order('date', { ascending: false });
    if (error) throw error;
    return data;
  });

  if (isLoading) return <p>Loading moods...</p>;
  if (error) return <p>Error loading moods: {error.message}</p>;
  const entries = data || [];
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold">Recent Mood Entries</h3>
      <ul className="space-y-2">
        {entries.map((entry) => (
          <li key={entry.id} className="border rounded p-2">
            <div className="flex justify-between">
              <span className="font-medium">{entry.date}</span>
              <span>Score: {entry.score}</span>
            </div>
            {entry.note && <p className="text-sm text-gray-600">{entry.note}</p>}
          </li>
        ))}
      </ul>
      <MoodChart
        entries={entries
          .slice()
          .reverse() // chronological for chart
          .map((e) => ({ date: e.date, score: e.score }))}
      />
    </div>
  );
};

export default MoodList;