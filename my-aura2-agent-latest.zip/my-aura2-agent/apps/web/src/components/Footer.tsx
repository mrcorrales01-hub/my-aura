import React from 'react';

/**
 * Application footer. Displays copyright information and links.
 */
const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-100 text-gray-600 text-sm py-4 mt-auto">
      <div className="container mx-auto px-4 flex justify-between">
        <span>© {new Date().getFullYear()} My Aura</span>
        <a href="/settings" className="hover:underline">
          Settings
        </a>
      </div>
    </footer>
  );
};

export default Footer;