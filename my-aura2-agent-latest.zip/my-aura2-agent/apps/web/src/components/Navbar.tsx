import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import LanguageSwitcher from '@/features/settings/LanguageSwitcher';

/**
 * Top navigation bar. It includes links to the core pages and the
 * language selector. Active links are highlighted.
 */
const Navbar: React.FC = () => {
  const location = useLocation();
  const navItems = [
    { path: '/', label: 'Home' },
    { path: '/chat', label: 'Chat' },
    { path: '/mood', label: 'Mood' },
    { path: '/media', label: 'Media' },
    { path: '/plan', label: 'Plan' },
  ];
  return (
    <header className="bg-aura-primary text-white shadow">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <h1 className="text-xl font-semibold">
          <Link to="/">My Aura</Link>
        </h1>
        <nav className="flex space-x-4">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={
                location.pathname === item.path
                  ? 'font-bold border-b-2 border-white'
                  : 'hover:opacity-80'
              }
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <LanguageSwitcher />
      </div>
    </header>
  );
};

export default Navbar;