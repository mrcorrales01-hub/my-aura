import React from 'react';

interface MoodEntry {
  date: string;
  score: number;
}

interface MoodChartProps {
  entries: MoodEntry[];
}

/**
 * Renders a simple bar chart using SVG to show mood scores over time.
 * Since external chart libraries are not used, this component keeps
 * visualization lightweight and dependency-free.
 */
const MoodChart: React.FC<MoodChartProps> = ({ entries }) => {
  // Determine maximum score for scaling
  const maxScore = 5;
  const barWidth = entries.length > 0 ? 100 / entries.length : 0;
  return (
    <div className="w-full h-40">
      <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        {entries.map((entry, index) => {
          const barHeight = (entry.score / maxScore) * 100;
          return (
            <rect
              key={entry.date}
              x={`${index * barWidth}`}
              y={`${100 - barHeight}`}
              width={`${barWidth - 1}`}
              height={`${barHeight}`}
              fill="currentColor"
              className="text-aura-primary"
            />
          );
        })}
      </svg>
    </div>
  );
};

export default MoodChart;