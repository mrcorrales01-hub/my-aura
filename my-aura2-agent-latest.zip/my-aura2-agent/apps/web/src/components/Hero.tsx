import React from 'react';
import { Link } from 'react-router-dom';

/**
 * Hero component for the landing page. Displays a welcome message and
 * calls to action to sign up or learn more.
 */
const Hero: React.FC = () => {
  return (
    <section className="bg-gradient-to-r from-aura-primary to-aura-secondary text-white py-20 px-4 rounded-2xl shadow-lg">
      <div className="container mx-auto flex flex-col items-center text-center">
        <h2 className="text-4xl font-extrabold mb-4">Welcome to My Aura</h2>
        <p className="mb-8 max-w-xl">
          Your personal mental wellbeing companion. Track your mood, chat with
          Auri and achieve your goals with personalised care plans.
        </p>
        <div className="flex space-x-4">
          <Link
            to="/auth"
            className="bg-white text-aura-primary px-6 py-3 rounded-lg font-semibold shadow hover:bg-gray-100"
          >
            Get Started
          </Link>
          <a
            href="#features"
            className="border-white border px-6 py-3 rounded-lg font-semibold hover:bg-white hover:text-aura-primary"
          >
            Learn More
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;