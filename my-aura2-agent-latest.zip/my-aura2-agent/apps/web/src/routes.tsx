import Index from '@/pages/Index';
import Auth from '@/pages/Auth';
import Chat from '@/pages/Chat';
import Mood from '@/pages/Mood';
import Media from '@/pages/Media';
import Settings from '@/pages/Settings';
import Plan from '@/pages/Plan';
import NotFound from '@/pages/NotFound';

/**
 * Defines the client-side routes for the application. Each route maps
 * a path to a component. Additional routes can be added here as the
 * application grows.
 */
const routes = [
  { path: '/', component: Index },
  { path: '/auth', component: Auth },
  { path: '/chat', component: Chat },
  { path: '/mood', component: Mood },
  { path: '/media', component: Media },
  { path: '/settings', component: Settings },
  { path: '/plan', component: Plan },
  { path: '*', component: NotFound },
];

export default routes;