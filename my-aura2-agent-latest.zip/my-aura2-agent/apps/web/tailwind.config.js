/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './index.html',
    './src/**/*.{ts,tsx,js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        'aura-primary': 'var(--aura-primary)',
        'aura-secondary': 'var(--aura-secondary)',
      },
    },
  },
  plugins: [],
};