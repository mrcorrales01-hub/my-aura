# My Aura 2.0 — Agent Build

This repository contains a clean scaffold for **My Aura 2.0**, built as a full‐stack TypeScript application.  It includes a modern React frontend, Supabase‐backed authentication, database migrations and edge function stubs.  The project is designed to serve as the foundation for the next generation of My Aura, featuring a multilingual UI, mood tracking, AI chat via Auri and a care plan system.

> **Note:** This repository provides a working file structure and baseline code.  You will need to install dependencies and set up a Supabase project to run the application.  Due to network restrictions in this development environment, npm packages are not preinstalled.

## Getting Started

### Prerequisites

* [Node.js](https://nodejs.org/) v16+ and npm
* [Supabase CLI](https://supabase.com/docs/guides/cli) (for database migrations and functions)

### Setup

1. **Clone or extract the repository**.  This code lives under the `my-aura2-agent` directory.
2. **Install dependencies** for the web app:

   ```bash
   cd my-aura2-agent/apps/web
   npm install
   ```

3. **Copy environment variables**:

   Copy `.env.example` to `.env` in the root of the web app and fill in your Supabase project details:

   ```env
   VITE_SUPABASE_URL=https://your-project.supabase.co
   VITE_SUPABASE_PUBLISHABLE_KEY=your-anon-key
   VITE_DEFAULT_LOCALE=sv
   VITE_SUPPORTED_LOCALES=sv,en,es,da,no,fi
   ```

4. **Initialize Supabase** (one time):

   ```bash
   cd my-aura2-agent
   supabase init
   supabase link --project-ref <your-project-ref>
   ```

5. **Run database migrations and seed**:

   ```bash
   supabase db reset     # This will apply migrations and seed data
   # or, if you want to push without resetting existing data:
   # supabase db push
   # supabase db seed supabase/seed/seed.sql
   ```

6. **Deploy the edge function**:

   Add your OpenAI/Anthropic API key to Supabase secrets:

   ```bash
   supabase secrets set OPENAI_API_KEY=sk-xxx
   # or ANTHROPIC_API_KEY=xxx
   supabase functions deploy chat
   ```

### Running Locally

In one terminal, start the Supabase local development stack:

```bash
supabase start
```

In another terminal, run the web application:

```bash
cd my-aura2-agent/apps/web
npm run dev
```

Visit [http://localhost:5173](http://localhost:5173) in your browser.  You should see the landing page.  Use the language selector or first‐run modal to choose your preferred language.

### Building for Production

To create an optimized build of the web app:

```bash
cd my-aura2-agent/apps/web
npm run build
```

The output will be in `dist/`.

### Project Structure

```text
my-aura2-agent/
├── .env.example            # Environment variable template
├── README.md               # This file
├── apps/
│   └── web/                # Frontend app
│       ├── package.json
│       ├── vite.config.ts
│       ├── tsconfig.json
│       ├── postcss.config.js
│       ├── tailwind.config.js
│       ├── src/
│       │   ├── app/        # Providers (React Query etc.)
│       │   ├── components/ # Reusable UI components
│       │   ├── features/   # Feature modules (auth, chat, mood, media, settings)
│       │   ├── lib/        # i18n and Supabase client
│       │   ├── pages/      # Route pages
│       │   ├── routes.tsx  # Route definitions
│       │   ├── App.tsx     # App shell with navbar and footer
│       │   └── main.tsx    # Entry point
│       └── styles/
│           └── index.css   # Tailwind imports and custom CSS
└── supabase/
    ├── functions/
    │   └── chat/           # Edge function for AI chat
    │       └── index.ts
    ├── migrations/         # SQL migrations defining the database schema
    │   └── 001_initial.sql
    └── seed/               # Seed data for videos and quests
        └── seed.sql
```

## Developing Further

This skeleton provides the basic groundwork for the project described in the agent prompt.  It includes:

* A multilingual React application with a first‐run language modal (to be implemented) and a language selector.
* Integration with Supabase for authentication and data storage.
* Sample UI for mood tracking, chat, video exercises and a placeholder care plan page.
* SQL migrations defining the required tables and row level security (RLS) policies.
* A Deno edge function stub for streaming chat responses.  Replace the placeholder implementation with calls to your preferred AI provider.

Many features described in the full specification (such as the care plan wizard, micro‐quests, Aura score calculation and real‐time support groups) are not fully implemented in this skeleton but can be built on top of the provided structure.

---

**Checklists**

* [ ] Set your Supabase project URL and anon key in `.env`.
* [ ] Install npm dependencies in `apps/web` and run the dev server.
* [ ] Initialize Supabase CLI, link your project and apply migrations.
* [ ] Deploy the `chat` edge function and set your LLM API key via `supabase secrets`.
* [ ] Implement remaining screens and business logic (care plans, quests, reports, etc.).
