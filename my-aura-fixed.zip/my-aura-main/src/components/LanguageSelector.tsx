import { useState } from "react";
import i18n from "@/i18n";
import { setLanguage, LANGS, type Lang } from "@/i18n";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Globe } from "lucide-react";

const LABELS: Record<string, string> = {
  en: "English", sv: "Svenska", es: "Español", de: "Deutsch", fr: "Français",
  pt: "Português", it: "Italiano", nl: "Nederlands", ru: "Русский", ar: "العربية",
  tr: "Türkçe", pl: "Polski", ja: "日本語", ko: "한국어", "zh-CN": "简体中文",
  "zh-TW": "繁體中文", hi: "हिन्दी", bn: "বাংলা", fa: "فارسی", th: "ไทย",
  vi: "Tiếng Việt", id: "Bahasa Indonesia", fil: "Filipino"
};

export default function LanguageSelector() {
  const [open, setOpen] = useState(false);

  const handle = async (code: string) => {
    await setLanguage(code as Lang);
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Globe className="h-4 w-4" />
          <span className="hidden sm:inline">{LABELS[i18n.language] ?? i18n.language}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Select language</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-2 max-h-[60vh] overflow-auto">
          {(LANGS as readonly string[]).map((code) => (
            <Button key={code}
                    onClick={() => handle(code)}
                    variant={i18n.language === code ? "default" : "outline"}
                    className="justify-start">
              {LABELS[code] ?? code}
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
