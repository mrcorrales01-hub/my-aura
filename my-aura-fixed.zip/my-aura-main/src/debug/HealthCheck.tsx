import { useEffect, useState } from "react";
import i18n from "@/i18n";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

type Check = { name: string; status: "ok" | "warn" | "error"; detail?: string };

export default function HealthCheck() {
  const [checks, setChecks] = useState<Check[]>([]);

  useEffect(() => {
    const res: Check[] = [];

    // i18n
    try {
      const lang = i18n.language;
      const t = i18n.t("common.ok");
      res.push({ name: `i18n (${lang})`, status: "ok" });
    } catch (e: any) {
      res.push({ name: "i18n", status: "warn", detail: String(e) });
    }

    // Supabase env
    const url = (import.meta as any).env?.VITE_SUPABASE_URL;
    const key = (import.meta as any).env?.VITE_SUPABASE_PUBLISHABLE_KEY;
    if (url && key) res.push({ name: "Supabase env", status: "ok" });
    else res.push({ name: "Supabase env", status: "warn", detail: "Missing VITE_SUPABASE_URL or VITE_SUPABASE_PUBLISHABLE_KEY" });

    setChecks(res);
  }, []);

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <CardTitle>Aura System Health</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {checks.map((c) => (
              <li key={c.name} className="flex items-start gap-3">
                <span className={
                  c.status === "ok" ? "text-green-600" : c.status === "warn" ? "text-yellow-600" : "text-red-600"
                }>
                  ●
                </span>
                <div>
                  <div className="font-medium">{c.name}</div>
                  {c.detail && <div className="text-sm opacity-80">{c.detail}</div>}
                </div>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
