import i18n from "i18next";
import { initReactI18next } from "react-i18next";

// Supported languages (BCP-47 where relevant)
export const LANGS = [
  "en","sv","es","de","fr","pt","it","nl","ru","ar","tr","pl","ja","ko","zh-CN","zh-TW","hi","bn","fa","th","vi","id","fil"
] as const;
export type Lang = typeof LANGS[number];
export const RTL_LANGUAGES = ["ar","fa"] as const;

// Initialize once
if (!i18n.isInitialized) {
  i18n
    .use(initReactI18next)
    .init({
      lng: "sv",
      fallbackLng: "en",
      interpolation: { escapeValue: false },
      defaultNS: "translation",
      ns: ["translation"],
      // We will add resources dynamically with loadLocale()
      resources: {},
      // Show keys if translations missing, helpful during debugging
      returnEmptyString: false,
      saveMissing: false,
    });
}

export async function loadLocale(lang: Lang) {
  try {
    const mod = await import(`@/locales/${lang}.json`);
    const resources = mod.default ?? mod;
    // Merge/replace bundle safely
    if (!i18n.hasResourceBundle(lang, "translation")) {
      i18n.addResourceBundle(lang, "translation", resources, true, true);
    } else {
      // replace to ensure fresh load
      i18n.removeResourceBundle(lang, "translation");
      i18n.addResourceBundle(lang, "translation", resources, true, true);
    }
  } catch (err) {
    console.warn(`[i18n] Failed to load locale "${lang}", falling back to English`, err);
    if (lang !== "en") {
      const en = await import(`@/locales/en.json`);
      i18n.addResourceBundle("en", "translation", en.default ?? en, true, true);
    }
  }
}

export async function setLanguage(lang: Lang) {
  if (!LANGS.includes(lang)) return;
  await loadLocale(lang);
  await i18n.changeLanguage(lang);
  localStorage.setItem("aura.lang", lang);
  document.documentElement.dir = (RTL_LANGUAGES as readonly string[]).includes(lang) ? "rtl" : "ltr";
  document.documentElement.lang = lang;
}

export async function initializeLanguage() {
  const stored = (localStorage.getItem("aura.lang") || "sv") as Lang;
  const lang: Lang = (LANGS as readonly string[]).includes(stored) ? (stored as Lang) : "sv";
  await setLanguage(lang);
}

export default i18n;
