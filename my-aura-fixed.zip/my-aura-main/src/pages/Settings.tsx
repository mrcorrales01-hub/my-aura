import { EnhancedSettings } from "@/components/EnhancedSettings";

const Settings = () => {
  return <EnhancedSettings />;
};

export default Settings;