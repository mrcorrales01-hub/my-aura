import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useQueryClient } from '@tanstack/react-query';

/**
 * Form to submit a mood entry with score (1–5) and optional note.
 * On submission, the entry is saved to Supabase and React Query cache
 * invalidated to refresh the mood list.
 */
const MoodForm: React.FC = () => {
  const [score, setScore] = useState(3);
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);
  const queryClient = useQueryClient();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { error } = await supabase
        .from('mood_entries')
        .insert({ score, note, date: new Date().toISOString().slice(0, 10) });
      if (error) {
        console.error(error.message);
      } else {
        setScore(3);
        setNote('');
        // Invalidate mood_entries cache
        queryClient.invalidateQueries(['mood_entries']);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-md mx-auto">
      <h2 className="text-xl font-bold">Log your mood</h2>
      <div>
        <label className="block mb-2">Mood score: {score}</label>
        <input
          type="range"
          min={1}
          max={5}
          value={score}
          onChange={(e) => setScore(parseInt(e.target.value))}
          className="w-full"
        />
      </div>
      <div>
        <label className="block mb-2">Note (optional)</label>
        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          className="w-full rounded border-gray-300 focus:border-aura-primary focus:ring-aura-primary"
          rows={3}
        />
      </div>
      <button
        type="submit"
        disabled={loading}
        className="bg-aura-primary text-white px-4 py-2 rounded"
      >
        {loading ? 'Saving...' : 'Save mood'}
      </button>
    </form>
  );
};

export default MoodForm;