import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface Video {
  id: string;
  title: string;
  url: string;
  durationSec: number;
  tags: string[];
  is_premium: boolean;
}

// Placeholder list of video exercises; in a real app, these would be
// fetched from Supabase or another API. The URLs here are generic and
// should be replaced with actual video links.
const videos: Video[] = [
  {
    id: '1',
    title: 'Relaxing Breathwork',
    url: 'https://samplelib.com/lib/preview/mp4/sample-5s.mp4',
    durationSec: 300,
    tags: ['andning', 'lugn'],
    is_premium: false,
  },
  {
    id: '2',
    title: 'Focus Meditation',
    url: 'https://samplelib.com/lib/preview/mp4/sample-5s.mp4',
    durationSec: 480,
    tags: ['fokus', 'stress'],
    is_premium: true,
  },
  {
    id: '3',
    title: 'Morning Energy Boost',
    url: 'https://samplelib.com/lib/preview/mp4/sample-5s.mp4',
    durationSec: 360,
    tags: ['energi', 'motivation'],
    is_premium: false,
  },
];

interface Progress {
  [videoId: string]: number;
}

/**
 * VideoList displays exercise videos and allows users to favorite them,
 * track their progress, and get recommendations based on their mood.
 * For the MVP, this component stores favorites and progress locally.
 */
const VideoList: React.FC = () => {
  const [favorites, setFavorites] = useState<string[]>([]);
  const [progress, setProgress] = useState<Progress>({});

  useEffect(() => {
    const favStr = localStorage.getItem('favoriteVideos');
    if (favStr) setFavorites(JSON.parse(favStr));
    const progStr = localStorage.getItem('videoProgress');
    if (progStr) setProgress(JSON.parse(progStr));
  }, []);

  useEffect(() => {
    localStorage.setItem('favoriteVideos', JSON.stringify(favorites));
  }, [favorites]);
  useEffect(() => {
    localStorage.setItem('videoProgress', JSON.stringify(progress));
  }, [progress]);

  const toggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  };

  const handleTimeUpdate = (id: string, currentTime: number, duration: number) => {
    setProgress((prev) => ({ ...prev, [id]: currentTime }));
    // Example: mark completed if > 90%
    if (currentTime / duration >= 0.9) {
      setProgress((prev) => ({ ...prev, [id]: duration }));
    }
  };

  const getContinueWatching = () => {
    return videos.filter((v) => {
      const time = progress[v.id] || 0;
      return time > 5 && time < v.durationSec * 0.9;
    });
  };

  // Simple mood-based recommendation: we could derive this from mood_entries but here just rotate
  const getRecommended = () => {
    return videos.filter((v) => !favorites.includes(v.id)).slice(0, 2);
  };

  return (
    <div className="space-y-8">
      <section>
        <h3 className="text-lg font-semibold mb-2">Continue watching</h3>
        {getContinueWatching().length === 0 ? (
          <p>No unfinished videos.</p>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {getContinueWatching().map((video) => (
              <VideoCard
                key={video.id}
                video={video}
                favorite={favorites.includes(video.id)}
                onToggleFavorite={() => toggleFavorite(video.id)}
                progress={progress[video.id] || 0}
                onTimeUpdate={handleTimeUpdate}
              />
            ))}
          </div>
        )}
      </section>
      <section>
        <h3 className="text-lg font-semibold mb-2">Recommended for you</h3>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {getRecommended().map((video) => (
            <VideoCard
              key={video.id}
              video={video}
              favorite={favorites.includes(video.id)}
              onToggleFavorite={() => toggleFavorite(video.id)}
              progress={progress[video.id] || 0}
              onTimeUpdate={handleTimeUpdate}
            />
          ))}
        </div>
      </section>
    </div>
  );
};

interface VideoCardProps {
  video: Video;
  favorite: boolean;
  progress: number;
  onToggleFavorite: () => void;
  onTimeUpdate: (id: string, currentTime: number, duration: number) => void;
}

/**
 * VideoCard renders an individual video with a favorite button, progress
 * indicator and embedded video player. It calls back to update
 * progress in the parent component.
 */
const VideoCard: React.FC<VideoCardProps> = ({
  video,
  favorite,
  progress,
  onToggleFavorite,
  onTimeUpdate,
}) => {
  return (
    <div className="relative border rounded-lg shadow p-2">
      <video
        controls
        src={video.url}
        className="w-full mb-2 rounded"
        onTimeUpdate={(e) =>
          onTimeUpdate(
            video.id,
            (e.target as HTMLVideoElement).currentTime,
            (e.target as HTMLVideoElement).duration || video.durationSec
          )
        }
      />
      <div className="flex justify-between items-center">
        <h4 className="font-semibold">{video.title}</h4>
        <button onClick={onToggleFavorite} aria-label="favorite">
          {favorite ? '★' : '☆'}
        </button>
      </div>
      {progress > 0 && (
        <div className="h-1 bg-gray-200 mt-1">
          <div
            className="h-full bg-aura-primary"
            style={{ width: `${(progress / video.durationSec) * 100}%` }}
          />
        </div>
      )}
    </div>
  );
};

export default VideoList;