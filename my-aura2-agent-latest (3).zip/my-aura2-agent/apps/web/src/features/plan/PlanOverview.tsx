import React from 'react';
import { useTranslation } from 'react-i18next';

/**
 * Displays a summary of the active care plan.
 * Currently just a placeholder until persistence is implemented.
 */
const PlanOverview: React.FC = () => {
  const { t } = useTranslation();
  // In a real implementation, query the active plan from Supabase
  const hasPlan = false;
  return (
    <div className="space-y-2">
      <h3 className="text-xl font-bold">{t('plan.overview.title')}</h3>
      {!hasPlan ? (
        <p>{t('plan.overview.noPlan')}</p>
      ) : (
        <p>{t('plan.overview.title')}</p>
      )}
    </div>
  );
};

export default PlanOverview;