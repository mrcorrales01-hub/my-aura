import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';

interface LongTermGoal {
  title: string;
  description: string;
  targetDate: string;
  smart: {
    specific: string;
    measurable: string;
    achievable: string;
    relevant: string;
    timeBound: string;
  };
}

interface ShortTermGoal {
  id: number;
  title: string;
  description: string;
  targetDate: string;
}

/**
 * A very simple multi‑step wizard for creating a care plan.
 * This implementation uses local state only and does not persist data.
 */
const PlanWizard: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const { t } = useTranslation();
  // wizard step (0‑4)
  const [step, setStep] = useState(0);
  // selected focus areas
  const [focusAreas, setFocusAreas] = useState<string[]>([]);
  // long term goal
  const [longGoal, setLongGoal] = useState<LongTermGoal>({
    title: '',
    description: '',
    targetDate: '',
    smart: { specific: '', measurable: '', achievable: '', relevant: '', timeBound: '' },
  });
  // short term goals
  const [shortGoals, setShortGoals] = useState<ShortTermGoal[]>([]);

  const maxShort = 3;

  const toggleFocus = (key: string) => {
    setFocusAreas(prev =>
      prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]
    );
  };

  const handleLongGoalChange = (field: keyof LongTermGoal, value: string) => {
    if (field === 'smart') return;
    setLongGoal(prev => ({ ...prev, [field]: value } as LongTermGoal));
  };

  const handleSmartChange = (field: keyof LongTermGoal['smart'], value: string) => {
    setLongGoal(prev => ({ ...prev, smart: { ...prev.smart, [field]: value } }));
  };

  const handleShortGoalChange = (id: number, field: keyof ShortTermGoal, value: string) => {
    setShortGoals(prev =>
      prev.map(g => (g.id === id ? { ...g, [field]: value } : g))
    );
  };

  const addShortGoal = () => {
    if (shortGoals.length >= maxShort) return;
    setShortGoals(prev => [...prev, { id: Date.now(), title: '', description: '', targetDate: '' }]);
  };

  const removeShortGoal = (id: number) => {
    setShortGoals(prev => prev.filter(g => g.id !== id));
  };

  const next = () => setStep(s => Math.min(s + 1, 4));
  const back = () => setStep(s => Math.max(s - 1, 0));
  const finish = () => {
    // placeholder: in real implementation, persist the plan to Supabase
    onComplete();
  };

  return (
    <div className="space-y-6">
      {step === 0 && (
        <div>
          <h3 className="text-xl font-bold mb-2">{t('plan.wizard.step1.title')}</h3>
          <p className="mb-4 text-sm text-gray-600">{t('plan.wizard.step1.subtitle')}</p>
          <div className="grid grid-cols-2 gap-2">
            {(['sleep', 'anxiety', 'stress', 'energy', 'social', 'focus'] as const).map(key => (
              <label key={key} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={focusAreas.includes(key)}
                  onChange={() => toggleFocus(key)}
                />
                <span>{t(`plan.wizard.step1.options.${key}`)}</span>
              </label>
            ))}
          </div>
        </div>
      )}
      {step === 1 && (
        <div className="space-y-4">
          <h3 className="text-xl font-bold mb-2">{t('plan.wizard.step2.title')}</h3>
          <div className="space-y-2">
            <label className="block">
              <span className="block text-sm font-medium">{t('plan.wizard.step2.fields.title')}</span>
              <input
                type="text"
                className="w-full border p-2 rounded"
                value={longGoal.title}
                onChange={e => handleLongGoalChange('title', e.target.value)}
              />
            </label>
            <label className="block">
              <span className="block text-sm font-medium">{t('plan.wizard.step2.fields.description')}</span>
              <textarea
                className="w-full border p-2 rounded"
                rows={3}
                value={longGoal.description}
                onChange={e => handleLongGoalChange('description', e.target.value)}
              ></textarea>
            </label>
            <label className="block">
              <span className="block text-sm font-medium">{t('plan.wizard.step2.fields.targetDate')}</span>
              <input
                type="date"
                className="w-full border p-2 rounded"
                value={longGoal.targetDate}
                onChange={e => handleLongGoalChange('targetDate', e.target.value)}
              />
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {(['specific', 'measurable', 'achievable', 'relevant', 'timeBound'] as const).map(field => (
                <label key={field} className="block">
                  <span className="block text-sm font-medium">
                    {t(`plan.wizard.step2.fields.smart.${field}`)}
                  </span>
                    <input
                      type="text"
                      className="w-full border p-2 rounded"
                      value={longGoal.smart[field]}
                      onChange={e => handleSmartChange(field, e.target.value)}
                    />
                </label>
              ))}
            </div>
          </div>
        </div>
      )}
      {step === 2 && (
        <div className="space-y-4">
          <h3 className="text-xl font-bold mb-2">{t('plan.wizard.step3.title')}</h3>
          <p className="text-sm text-gray-600">{t('plan.wizard.step3.limitNote')}</p>
          <button
            type="button"
            className="bg-blue-500 text-white px-3 py-1 rounded"
            disabled={shortGoals.length >= maxShort}
            onClick={addShortGoal}
          >
            {t('plan.wizard.step3.addGoal')}
          </button>
          {shortGoals.map((goal, idx) => (
            <div key={goal.id} className="border p-3 rounded space-y-2">
              <h4 className="font-semibold">{t('plan.goals.shortTerm')} {idx + 1}</h4>
              <label className="block">
                <span className="block text-sm font-medium">{t('plan.wizard.step2.fields.title')}</span>
                <input
                  type="text"
                  className="w-full border p-2 rounded"
                  value={goal.title}
                  onChange={e => handleShortGoalChange(goal.id, 'title', e.target.value)}
                />
              </label>
              <label className="block">
                <span className="block text-sm font-medium">{t('plan.wizard.step2.fields.description')}</span>
                <textarea
                  className="w-full border p-2 rounded"
                  rows={2}
                  value={goal.description}
                  onChange={e => handleShortGoalChange(goal.id, 'description', e.target.value)}
                ></textarea>
              </label>
              <label className="block">
                <span className="block text-sm font-medium">{t('plan.wizard.step2.fields.targetDate')}</span>
                <input
                  type="date"
                  className="w-full border p-2 rounded"
                  value={goal.targetDate}
                  onChange={e => handleShortGoalChange(goal.id, 'targetDate', e.target.value)}
                />
              </label>
              <button
                type="button"
                className="text-red-600 text-sm"
                onClick={() => removeShortGoal(goal.id)}
              >
                {t('plan.wizard.remove')}
              </button>
            </div>
          ))}
        </div>
      )}
      {step === 3 && (
        <div>
          <h3 className="text-xl font-bold mb-2">{t('plan.wizard.step4.title')}</h3>
          <p className="text-sm text-gray-600 mb-4">{t('plan.wizard.step4.autoGenerate')}</p>
          {/* For simplicity, just list number of tasks equal to number of focus areas */}
          <ul className="list-disc pl-6 space-y-1">
            {focusAreas.map((area, idx) => (
              <li key={idx}>
                {t('plan.tasks.title')}: {t(`plan.wizard.step1.options.${area}`)} – {t('plan.wizard.step4.tasksPerWeek')} 1
              </li>
            ))}
          </ul>
        </div>
      )}
      {step === 4 && (
        <div className="space-y-4">
          <h3 className="text-xl font-bold mb-2">{t('plan.wizard.step5.title')}</h3>
          <p>{t('plan.wizard.step5.startPlan')}</p>
          <div className="space-y-1 text-sm">
            <p><strong>{t('plan.wizard.step1.title')}:</strong> {focusAreas.map(a => t(`plan.wizard.step1.options.${a}`)).join(', ')}</p>
            <p><strong>{t('plan.wizard.step2.fields.title')}:</strong> {longGoal.title}</p>
            <p><strong>{t('plan.wizard.step2.fields.description')}:</strong> {longGoal.description}</p>
            <p><strong>{t('plan.wizard.step2.fields.targetDate')}:</strong> {longGoal.targetDate}</p>
            <p><strong>{t('plan.goals.shortTerm')}:</strong> {shortGoals.length}</p>
          </div>
        </div>
      )}
      <div className="flex justify-between pt-4">
        {step > 0 ? (
          <button type="button" className="px-4 py-2 border rounded" onClick={back}>
            {t('plan.wizard.back')}
          </button>
        ) : (
          <div />
        )}
        {step < 4 ? (
          <button type="button" className="px-4 py-2 bg-blue-600 text-white rounded" onClick={next}>
            {t('plan.wizard.next')}
          </button>
        ) : (
          <button type="button" className="px-4 py-2 bg-green-600 text-white rounded" onClick={finish}>
            {t('plan.wizard.finish')}
          </button>
        )}
      </div>
    </div>
  );
};

export default PlanWizard;