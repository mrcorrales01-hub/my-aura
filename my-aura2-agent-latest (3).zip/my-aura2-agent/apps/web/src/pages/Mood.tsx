import React from 'react';
import MoodForm from '@/features/mood/MoodForm';
import MoodList from '@/features/mood/MoodList';

/**
 * Mood page. Allows users to log their mood and view previous entries.
 */
const MoodPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <MoodForm />
      <MoodList />
    </div>
  );
};

export default MoodPage;