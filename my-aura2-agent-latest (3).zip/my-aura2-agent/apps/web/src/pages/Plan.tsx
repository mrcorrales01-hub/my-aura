import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import PlanOverview from '@/features/plan/PlanOverview';
import PlanWizard from '@/features/plan/PlanWizard';

/**
 * Plan page. Displays the user's care plan and allows creation via a wizard.
 */
const PlanPage: React.FC = () => {
  const { t } = useTranslation();
  const [creating, setCreating] = useState(false);
  const [planExists, setPlanExists] = useState(false);
  const handleComplete = () => {
    setCreating(false);
    setPlanExists(true);
  };
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">{t('plan.nav')}</h2>
      {!creating && (
        <>
          <PlanOverview />
          {!planExists && (
            <button
              type="button"
              className="bg-blue-600 text-white px-4 py-2 rounded"
              onClick={() => setCreating(true)}
            >
              {t('plan.overview.createPlan')}
            </button>
          )}
        </>
      )}
      {creating && <PlanWizard onComplete={handleComplete} />}
    </div>
  );
};

export default PlanPage;