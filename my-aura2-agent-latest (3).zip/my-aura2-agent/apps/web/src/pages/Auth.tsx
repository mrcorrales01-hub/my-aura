import React from 'react';
import AuthForm from '@/features/auth/AuthForm';

/**
 * Authentication page. Renders the AuthForm for magic link login.
 */
const AuthPage: React.FC = () => {
  return (
    <div className="flex justify-center items-start mt-10">
      <AuthForm />
    </div>
  );
};

export default AuthPage;