import { createClient } from '@supabase/supabase-js';

// Create a single supabase client for the application. The URL and
// anonymous key must be provided via environment variables. These values
// should be set in a .env file at project root (see .env.example).
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);